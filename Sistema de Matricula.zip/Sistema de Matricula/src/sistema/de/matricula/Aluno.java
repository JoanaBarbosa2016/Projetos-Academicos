/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistema.de.matricula;


/**
 *
 * @author aluno
 */

public class Aluno 
{
   
    private String codigo;
    private String nome;
    private String cpf; 
    private String curso; 
    


    public String getCodigo() 
    {
        return codigo;
    }

    public String getNome() 
    {
        int ultimaPosicao = Menu.listaNome.size() - 1;
        String ultimaPosicaoListaNome = Menu.listaNome.get(ultimaPosicao);
        
        return ultimaPosicaoListaNome;
    }

    public String getCpf() 
    {
        int ultimaPosicao = Menu.listaCpf.size() - 1;
        String ultimaPosicaoListaCpf = Menu.listaCpf.get(ultimaPosicao);
        
        return ultimaPosicaoListaCpf;
    }
    
     public String getCurso() 
    {
        int ultimaPosicao = Menu.listaCurso.size() - 1;
        String ultimaPosicaoListaCurso = Menu.listaCurso.get(ultimaPosicao);
        return ultimaPosicaoListaCurso;
    }

    public void setCodigo(String codigo) 
    {
        this.codigo = codigo;
    }

    public void setNome(String nome) 
    {
        Menu.listaNome.add(nome);
    }

    public void setCpf(String cpf) 
    {
        Menu.listaCpf.add(cpf);
    }
    
    public void setCurso(String curso) 
    {
        this.curso = curso;
    }   
}
