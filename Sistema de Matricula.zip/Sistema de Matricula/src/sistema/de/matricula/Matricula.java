/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistema.de.matricula;

import java.util.ArrayList;

/**
 *
 * @author aluno
 */
public class Matricula
{
    public static ArrayList<String> matriculaCpf = new ArrayList<String>();
    public static ArrayList<Integer> matriculaCodigoCurso = new ArrayList<Integer>();
        
    public void matricular(String cpf, Integer codigoCurso)// Adiciona o cpf e codigo de curso nas suas listas
    {
        matriculaCpf.add(cpf);
        matriculaCodigoCurso.add(codigoCurso);
    }
    
    /*
        Lista alunos matriculados nos cursos (Estão ligados pelo índice)
         Ex.: listaCurso[1] == Computacao
              listaAluno[1] == André
         Logo André está associado á computação
    */
    
    public void listaAlunosECursos()
    {
        System.out.println("**************************************************************");
        
        for(int cont = 0; cont < matriculaCpf.size(); cont++)
        {
            System.out.println(Menu.listaNome.get(cont) + "|| CPF : " + matriculaCpf.get(cont) + "|| Matriculado em " + Menu.listaCurso.get(cont));
        }
        
         System.out.println("**************************************************************");
    }

}