/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistema.de.matricula;
import java.sql.*;
import javax.swing.table.DefaultTableModel;
import java.util.Scanner;
/**
 *
 * @author aluno
 */
public class Persistencia
{
    Scanner ler = new Scanner(System.in);
    Aluno aluno = new Aluno();
    private static Connection conexao = null; 
    
    public Persistencia() throws ClassNotFoundException, SQLException, ClassNotFoundException
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/matricula", "root", "");
        }
        catch (Exception erro)
        {
            System.err.println("A aplicação encontrou o seguinte erro: \n" + erro);
        }
    }
    
    public static Connection conexao() throws ClassNotFoundException, SQLException
    {
        if (conexao == null)
             new Persistencia();
        
        return conexao;
    }
    
    PreparedStatement ps = null;
    
    
    
    public void insere() throws ClassNotFoundException
    {
        int cont = 0001;
        try
        {
            ps = Persistencia.conexao().prepareStatement("insert into aluno (matricula,nome,cpf,curso) values (?,?,?,?)");
            
            ps.setString(1, Integer.toString(cont));
            ps.setString(2, aluno.getNome());
            ps.setString(3, aluno.getCpf());
            ps.setString(4, aluno.getCurso());
            
            cont++;
            
            ps.executeUpdate();
        }
        catch(SQLException erro)
        {
            System.err.println("Erro ao executar SQL " + erro);
        }
    }
    
    public Boolean exclui(int matricula)
    {
        try
        {  
             ps = Persistencia.conexao().prepareStatement("Delete from aluno where matricula = " + matricula);
            
            
            ps.executeUpdate();
            
            return true;

        }
        catch(Exception erro)
        {
            System.err.println("Não foi possível executar o comando SQL");
            
            return false;
        }
    }
    
    public void carrega(int matricula)
    {
        try
        {
            int cont = 0;
            
            ps = Persistencia.conexao().prepareStatement("Select * from aluno where matricula = " + matricula);
            ResultSet rs = ps.executeQuery();
            
            DefaultTableModel dtm = new DefaultTableModel(new String[]{"nome", "curso", "matricula", "cpf"}, 0);
            
            while(rs.next())
            {
                String[] dados = {rs.getString("nome"), rs.getString("curso"), rs.getString("matricula"), rs.getString("cpf")};
                dtm.addRow(dados);
                System.out.println("***********************************************************************************");
                System.out.println(dados[cont]);
                System.out.println("***********************************************************************************");
                cont++;
            }
            
            System.out.println("Deseja excluir esta ocorrência do banco de dados?\n \n s->sim\n n->nao");
                    String resposta = ler.nextLine();
                    
                    if(resposta.equals("s"))
                    {
                        if(exclui(matricula))
                            System.out.println("\nAluno excluído com sucesso\n");
                        
                        else
                            System.err.println("\nErro ao excluir registro\n");
                        
                    }
                    else
                        return;
        }
        catch(Exception erro)
        {
            System.err.println("Não foi possível executar o comando SQL");
        }
    }
    
     
}
