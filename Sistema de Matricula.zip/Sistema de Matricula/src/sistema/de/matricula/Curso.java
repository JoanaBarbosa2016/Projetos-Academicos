/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistema.de.matricula;

import java.util.Random;

/**
 *
 * @author aluno
 */
public class Curso 
{
    
    Random gerar = new Random();
    
    private String nomeCurso;
    private String cargaHoraria;

    public String getNomeCurso()
    {
        return nomeCurso;
    }

    public String getCargaHoraria()
    {
        return cargaHoraria;
    }

    public int getCodigoCurso(String curso)
    {
        //Menu.listaCodigoCurso.
        
        return 1;
    }

    public void setNomeCurso(String nomeCurso)
    {
        Menu.listaCurso.add(nomeCurso); 
    }

    public void setCargaHoraria(String cargaHoraria)
    {
        this.cargaHoraria = cargaHoraria;
    }

    public void setCodigoCurso()
    {
        Menu.listaCodigoCurso.add(gerar.nextInt(10000));
    }
    
    
    
    
}
