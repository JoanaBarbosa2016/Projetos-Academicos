/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistema.de.matricula;

/**
 *
 * @author aluno
 */
import java.io.*;

public class RW
{
    Aluno aluno = new Aluno();
    
    public Boolean grava(String texto) throws IOException
    {
        try
        {
            FileWriter caminho = new FileWriter("arquivo.txt");
            PrintWriter gravar = new PrintWriter(caminho);
       
            gravar.println(texto);
            gravar.close();
            
            return true;
        }
        catch(Exception erro)
        {
            System.err.println("\n" + erro);
            
            return false;
        }
    }
    
    public Boolean leArquivo() throws IOException
    {
        try
        {
            FileReader caminho = new FileReader("arquivo.txt");
            BufferedReader ler = new BufferedReader(caminho);
            
            String[] array = new String[3];
            
            String linha = ler.readLine();
            
            //A cada par de '||' encontrado, ele guarda o que já leu em uma posição do array EX.: andre||1098, arrai{andre,1098}
            array = linha.split("||"); 
            
            while(linha != null)
            {                
                for(String s: array)
                {
                    aluno.setNome(array[1]);
                    aluno.setCodigo(array[2]);
                    aluno.setCurso(array[3]);
                    
                    //Estava lendo a linha vazia e ainda sim imprimindo itens do array --'
                    if(!linha.equals(""))
                        System.out.print(s);
                }
                
                linha = ler.readLine();
            }
            
            ler.close();
            
            return true;
        }
        
        catch(Exception erro)
        {
            System.err.println("Erro\n" + erro + "\n");
            
            return false;
        }
    }

}
