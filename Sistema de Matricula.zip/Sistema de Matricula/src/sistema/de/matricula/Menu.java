/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistema.de.matricula;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author aluno
 */
public class Menu
{
    //======================================Variáveis, objetos, listas======================================================
    
    public static ArrayList<String> listaNome = new ArrayList<String>();
    public static ArrayList<String> listaCpf = new ArrayList<String>();
    public static ArrayList<Integer> listaCodigoCurso = new ArrayList<Integer>();
    public static ArrayList<String> listaCurso = new ArrayList<String>();
    
    Scanner ler = new Scanner(System.in);
    
    Matricula matricula = new Matricula();
    Curso curso = new Curso();
    Aluno aluno = new Aluno();
    RW rw = new RW();
    
    
    byte opcao;

//===================================================== Métodos ============================================================
    
    public void executa()
    {
        try
        {
            System.out.println("\n>>>Escolha sua opção<<<\n");
                
            System.out.println
            (
                  "1-Cadastrar nome do aluno e CPF\n" + 
                  "2-Cadastrar curso\n" + 
                  "3-Listar todos os alunos\n" +
                  "4-listar todos os cursos\n" +
                  "5-Matricular aluno em um curso\n" +
                  "6-Listar alunos matriculados em cursos\n" +
                  "7-Gravar os dados em texto\n" + 
                  "8-Ler os arquivos em texto\n" +
                  "9-Procurar aluno no banco de dados\n" + 
                  "0-Finalizar\n"
            );
                                
            opcao = ler.nextByte();
                
            System.out.println("");
            
            Scanner ler = new Scanner(System.in);//Classe Scanner bugada me obrigando a fazer gambiarras
            
            switch(opcao)
            {
                case 1://=============== Cadastrar nome do aluno e CPF
                {   
                    try
                    {
                        System.out.println("Digite o nome do aluno\n");
                        aluno.setNome(ler.nextLine());
                        System.out.println("");

                        System.out.println("Agora digite o cpf deste aluno,\n");
                        aluno.setCpf(ler.nextLine());  
                        System.out.println("");
                   
                        System.out.println("\n****Aluno e CPF cadastrados****\n");    
                    } 
                    
                    catch (Exception erro)
                    {
                        System.out.println("\n****Erro no cadastro do aluno****\n");
                    }        
                    
                    break;
                }
                case 2: //========================== Cadastrar Curso (Após o cadastro um ID é associado automaticamente)
                {
                    try
                    {
                        System.out.println("Digite o nome do curso\n");
                        curso.setNomeCurso(ler.nextLine());
                        System.out.println("");
                        
                        curso.setCodigoCurso();// Método que vai gerar um ID aleatório ao curso
                        
                        System.out.println("\n****Curso cadastrado****\n"); 
                    }
                    catch(Exception erro)
                    {
                        System.err.println("\nErro interno " + erro);
                    }
                    
                    break;
                }
                case 3://========================== Listagem de todos os alunos cadastrados
                {
                    System.out.println("\n*********Lista de alunos cadastrados*********\n");
                        
                    for(int cont = 0; cont < listaNome.size(); cont++)
                    {
                        System.out.println((cont + 1) + "-" + listaNome.get(cont) + "|| CPF: " + listaCpf.get(cont) + "\n");
                    }
                    
                    System.out.println("\n*********************************************\n");
                        
                    break;
                }
                case 4://========================== Listagem de todos os cursos cadastrados
                {
                    System.out.println("\n*********Lista dos cursos cadastrados*********\n");
                        
                    for(int cont = 0; cont < listaCurso.size(); cont++)
                    {
                        System.out.println((cont + 1) + "-" + listaCurso.get(cont) + "|| Código:" + listaCodigoCurso.get(cont) + "\n");
                    }
                    
                    System.out.println("\n*********************************************\n");
                        
                    break;
                }
                
                case 5://===========================Associa o aluno á um curso
                {
                    System.out.println("Digite o CPF do aluno");
                    String cpfProcurado = ler.nextLine();
                    
                    Boolean parametrosSatisfeitos = true;//Para o método se o CPF ou o Codigo do curso não existir

                    for(int contador1 = 0; contador1 < listaCpf.size(); contador1++)//Procura o cpf digitado na lista
                    {
                        if(cpfProcurado.equals(listaCpf.get(contador1)))
                        {
                            System.out.println("\nAluno " + listaNome.get(contador1) + " encontrado\n");
                                
                            parametrosSatisfeitos = true;
                            
                            break;
                        }
                        
                        else
                        {
                            parametrosSatisfeitos = false;
                        }
                    }
                        
                    System.out.println("\nDigite o codigo do curso a ser matriculado\n");
                    int codigocursoProcurado = ler.nextInt();
                            
                    for(int contador2 = 0; contador2 < listaCodigoCurso.size(); contador2++)//Procura o código do curso digitado na lista
                    {
                        if(codigocursoProcurado == listaCodigoCurso.get(contador2))
                        {
                            System.out.println("Aluno " + listaNome.get(contador2) + " matriculado no curso " + listaCurso.get(contador2));
                            parametrosSatisfeitos = true; 
                            
                            break;
                        }
                        else
                        {
                           parametrosSatisfeitos = false;
                        }
                    }
                         
                    if(parametrosSatisfeitos)
                    {
                        matricula.matricular(cpfProcurado, codigocursoProcurado);
                    }
                    else
                    {
                        System.out.println("ERRO, ALUNO OU MATRÍCULA NÃO EXISTE");
                    }
                    
                    break;
                }
                
                case 6://Lista os alunos matriculados nos respectivos cursos
                {
                    matricula.listaAlunosECursos();
                    
                    break;
                }
                
                case 7://Grava os dados no arquivo txt
                {                    
                    for(int contador = 0; contador < listaNome.size(); contador++)
                    {
                       if(rw.grava(listaNome.get(contador) + "||" + listaCpf.get(contador) + "||" + listaCurso.get(contador) + "\n"))
                            System.out.println("\nOs arquivos foram gravados com sucesso\n");
                       
                       else
                           System.out.println("\nErro na gravação dos arquivos\n"); 
                    }
                    
                    Persistencia persistencia = new Persistencia();
                    
                    Persistencia.conexao();
                    persistencia.insere();
                    
                    break;
                }
                case 8://Lê os dados do txt e imprime na tela
                {
                    if(!rw.leArquivo())
                        System.out.println("Erro na leitura dos arquivos");
                    
                    break;
                }
                
                case 9:
                {
                    System.out.println("Digite o código de matrícula do aluno");
                    int codigo = ler.nextInt();
                    
                    Persistencia persistencia = new Persistencia();
                    
                    Persistencia.conexao();
                    persistencia.carrega(codigo);
                    
                    
                    
                    break;
                }

                case 0:
                {
                    System.out.println("\n****Programa filizado*****\n");
                    return;
                }
            }
                
            executa();
        }
        
        catch(Exception erro)
        {
            System.err.println("\nFinalizado devido a erro\n" + erro);
        }
    }
}
